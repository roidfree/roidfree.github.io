var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var posts_exports = {};
__export(posts_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(posts_exports);
var import_dotenv = __toESM(require("dotenv"), 1);
var import_client = require("@notionhq/client");
import_dotenv.default.config();
const notion = new import_client.Client({ auth: process.env.NOTION_API_KEY });
const databaseId = process.env.NOTION_DATABASE_ID;
const handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: ""
    };
  }
  try {
    console.log("Fetching posts from Notion database:", databaseId);
    const response = await notion.databases.query({
      database_id: databaseId,
      sorts: [{ property: "Publish Date", direction: "descending" }],
      filter: {
        and: [
          {
            property: "Status",
            status: {
              equals: "Published"
            }
          },
          {
            property: "Initiative",
            multi_select: {
              contains: "ANA"
            }
          }
        ]
      }
    });
    if (!response || !response.results) {
      throw new Error("Invalid response from Notion API");
    }
    const posts = response.results.map((page) => {
      const props = page.properties;
      return {
        id: page.id,
        title: props["Title"]?.title?.[0]?.plain_text || "Untitled",
        description: props["Summary"]?.rich_text?.[0]?.plain_text || "",
        date: props["Publish Date"]?.date?.start || "",
        tags: props["Tags"]?.multi_select?.map((tag) => tag.name) || [],
        coverImage: props["Featured Image"]?.url || null,
        url: `https://notion.so/${page.id.replace(/-/g, "")}`
      };
    }).filter(Boolean);
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(posts)
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Failed to fetch posts",
        message: error.message
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
